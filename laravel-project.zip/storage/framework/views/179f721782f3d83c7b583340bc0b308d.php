

<?php $__env->startSection('content'); ?>
    <div class="container-xxl py-5 bg-dark hero-header mb-5">
        <div class="container text-center my-5 pt-5 pb-4">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Reservation</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Reservation</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container">

        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Date</th>
                        <th scope="col">Num People</th>
                        <th scope="col">Message</th>
                        <th scope="col">Status</th>
                        <th scope="col">Review</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($reservation->name); ?></td>
                            <td><?php echo e($reservation->email); ?></td>
                            <td><?php echo e($reservation->date_time); ?></td>
                            <td><?php echo e($reservation->people_count); ?></td>
                            <td><?php echo e($reservation->message); ?></td>
                            <td><?php echo e($reservation->status); ?>

                                <?php if(empty($reservation->status)): ?>
                                    <form action="<?php echo e(route('reservations.arrived', $reservation->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button class="btn btn-success btn-sm">Mark as Arrived</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-success fw-bold">✅ Arrived</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($reservation->status == 'Arrived'): ?>
                                    <a href="<?php echo e(route('foods.reviews')); ?>" class="btn btn-success">Review</a>
                                <?php else: ?>
                                    <span class="text-muted">Not available yet</span>
                                <?php endif; ?>
                            </td> 
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/reservation/my_reservations.blade.php ENDPATH**/ ?>