

<?php $__env->startSection('content'); ?>
    <div class="container-xxl py-5 bg-dark hero-header mb-5" style="margin-top: -25px">
        <div class="container text-center my-5 pt-5 pb-4">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Cart</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Cart</a></li>
                </ol>
            </nav>
        </div>
    </div>
    </div>
    <div class="container">
        <?php if(session()->has('success')): ?>
            <p class="alert <?php echo e(session()->get('alert-class', 'alert-info')); ?>">
                <?php echo e(session()->get('success')); ?>

            </p>
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
            <p class="alert <?php echo e(session()->get('alert-class', 'alert-danger')); ?>">
                <?php echo e(session()->get('error')); ?>

            </p>
        <?php endif; ?>

    </div>
    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-md-6">
                    <div class="row g-3">
                        <div class="col-12 text-start">
                            <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.1s"
                                src="<?php echo e(asset('img/' . $foodItem->image . '')); ?>">
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">
                    <h1 class="mb-4"><?php echo e($foodItem->name); ?></h1>
                    <p class="mb-4"><?php echo e($foodItem->description); ?></p>

                    <div class="row g-4 mb-4">
                        <div class="col-sm-6">
                            <div class="d-flex align-items-center border-start border-5 border-primary px-3">
                                <h3>Price: $ <?php echo e($foodItem->price); ?></h3>
                            </div>
                        </div>

                    </div>
                    <?php if(Auth::check()): ?>
                        
                        <form method="post" action="<?php echo e(route('food.cart', $foodItem->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user-id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="food-id" value="<?php echo e($foodItem->id); ?>">
                            <input type="hidden" name="name" value="<?php echo e($foodItem->name); ?>">
                            <input type="hidden" name="image" value="<?php echo e($foodItem->image); ?>">
                            <input type="hidden" name="price" value="<?php echo e($foodItem->price); ?>">
                            <button type="submit" name="submit" class="btn btn-primary py-3 px-5 mt-2">
                                Add to Cart
                            </button>
                        </form>
                    <?php else: ?>
                        
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-warning py-3 px-5 mt-2">
                            Log in to add to cart
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/foods/food-details.blade.php ENDPATH**/ ?>