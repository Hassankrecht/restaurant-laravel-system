

<?php $__env->startSection('content'); ?>

    <div class="container-xxl py-5 bg-dark hero-header mb-5">
        <div class="container text-center my-5 pt-5 pb-4">
            <h1 class="display-3 text-white mb-3 animated slideInDown">My orders</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">My orders</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container">

        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Town</th>
                        <th scope="col">phone_number</th>
                        <th scope="col">price</th>
                        <th scope="col">Date</th>
                        <th scope="col">Status</th>
                        <th scope="col">Review</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($allOrders): ?>
                        <?php $__currentLoopData = $allOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($orders->name); ?></td>
                                <td><?php echo e($orders->email); ?></td>
                                <td><?php echo e($orders->town); ?></td>
                                <td><?php echo e($orders->phone_number); ?></td>
                                <td><?php echo e($orders->total_price); ?></td>
                                <td><?php echo e($orders->created_at->format('Y-m-d')); ?></td>
                                <td><?php echo e($orders->status); ?></td>
                                <?php if($orders->status == 'Delivered'): ?>
                                    <td><a href="<?php echo e(route('orders.delivered')); ?>" class="btn btn-success">Review</a>
                                    </td>
                                <?php else: ?>
                                    <td>not available yet </td>
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h3 class="alrt alert-success">you have no booking table yet</p>
                    <?php endif; ?>

                </tbody>
            </table>

        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/foods/my-orders.blade.php ENDPATH**/ ?>