

<?php $__env->startSection('content'); ?>
<div class="container-xxl py-5 bg-dark hero-header mb-5">
    <div class="container text-center my-5 pt-5 pb-4">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Order Confirmation</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center text-uppercase">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Order Confirmation</li>
            </ol>
        </nav>
    </div>
</div>

<div class="container mb-5">
    <div class="bg-dark text-white p-5 rounded">
        <h2>Thank you, <?php echo e($order->name); ?>!</h2>
        <p>Your order #<strong><?php echo e($order->id); ?></strong> has been placed successfully.</p>

        <h4 class="mt-4">Order Details:</h4>
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th>Food Item</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>$<?php echo e(number_format($item->price, 2)); ?></td>
                    <td>$<?php echo e(number_format($item->total_price, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h4 class="text-end">Total Price: $<?php echo e(number_format($order->total_price, 2)); ?></h4>

        <h4 class="mt-5">Shipping Information:</h4>
        <p><strong>Email:</strong> <?php echo e($order->email); ?></p>
        <p><strong>Phone:</strong> <?php echo e($order->phone_number); ?></p>
        <p><strong>Address:</strong> <?php echo e($order->address); ?>, <?php echo e($order->town); ?>, <?php echo e($order->country); ?>, <?php echo e($order->zipcode); ?></p>

        <div class="d-flex justify-content-between">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mt-4">Back to Home</a>
            <a href="<?php echo e(route('foods.payment', ['order_id' => $order->id])); ?>" class="btn btn-success mt-4">Proceed to PayPal</a>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/foods/order-confirmation.blade.php ENDPATH**/ ?>