

<?php $__env->startSection('content'); ?>
<div class="container-xxl py-5 bg-dark hero-header mb-5" style="margin-top: -25px">
    <div class="container text-center my-5 pt-5 pb-4">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Cart</h1>
    </div>
</div>

<div class="container">
    <div class="col-md-12">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php $total = 0; ?>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total += $item->price * $item->quantity; ?>
                    <tr>
                        <td><img src="<?php echo e(asset('img/' . $item->image)); ?>" style="width: 50px;"></td>
                        <td><?php echo e($item->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('cart.decreaseQuantity', $item->food_id)); ?>" method="POST" style="display:inline-flex;">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-sm btn-outline-secondary" type="submit">-</button>
                            </form>

                            <span class="mx-2 item-total"><?php echo e($item->quantity); ?></span>

                            <form action="<?php echo e(route('cart.increaseQuantity', $item->food_id)); ?>" method="POST" style="display:inline-flex;">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-sm btn-outline-secondary" type="submit">+</button>
                            </form>
                        </td>
                        <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                        <td>
                            <form action="<?php echo e(route('cart.destroy', $item->food_id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="text-end">
            <h4>Total: $<?php echo e(number_format($total, 2)); ?></h4>
            <?php if($total == 0): ?>
                <p class="alert alert-warning">Your cart is empty.</p>
            <?php else: ?>
                <form method="GET" action="<?php echo e(route('food.checkout.prepare', Auth::id())); ?>">
                    <button type="submit" class="btn btn-primary">Checkout</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/foods/cart-details.blade.php ENDPATH**/ ?>