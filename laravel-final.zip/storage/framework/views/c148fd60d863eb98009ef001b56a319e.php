<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>New Contact Message</title>
</head>
<body>
    <h2>New Message from <?php echo e($data['name']); ?></h2>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($data['subject']); ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\restorant\resources\views/emails/contact.blade.php ENDPATH**/ ?>