

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4 d-inline">Admins</h5>
                        <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary mb-4 text-center float-right">Create
                            Admins</a>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">username</th>
                                    <th scope="col">email</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo csrf_field(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($index + 1); ?></th>
                                        <td><?php echo e($admin->name); ?></td>
                                        <td><?php echo e($admin->email); ?></td>
                                        <td><a href="<?php echo e(route('admin.edit', $admin->id)); ?>"
                                                class="btn btn-sm btn-warning">Edit</a>
                                            <form action="<?php echo e(route('admin.destroy', $admin->id)); ?>" method="POST"
                                                style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/admins/index.blade.php ENDPATH**/ ?>