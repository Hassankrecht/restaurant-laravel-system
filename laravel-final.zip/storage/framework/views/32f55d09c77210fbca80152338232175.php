
|<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4 d-inline">Orders</h5>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">name</th>
                                    <th scope="col">email</th>
                                    <th scope="col">town</th>
                                    <th scope="col">country</th>
                                    <th scope="col">zipcode</th>
                                    <th scope="col">phone_number</th>
                                    <th scope="col">address</th>
                                    <th scope="col">total_price</th>
                                    <th scope="col">status</th>
                                    <th scope="col">delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo csrf_field(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($index + 1); ?></th>
                                        <td><?php echo e($order->name); ?></td>
                                        <td><?php echo e($order->email); ?></td>
                                        <td><?php echo e($order->town); ?></td>
                                        <td><?php echo e($order->country); ?></td>
                                        <td><?php echo e($order->zipcode); ?></td>
                                        <td><?php echo e($order->phone_number); ?></td>
                                        <td><?php echo e($order->address); ?></td>
                                        <td>$<?php echo e($order->total_price); ?></td>

                                        <td><?php echo e($order->status); ?></td>

                                        <td>
                                            <form action="<?php echo e(route('admin.orders.delete', $order->id)); ?>" method="POST"
                                                style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </td>
                                        
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>



    </div>
    <script type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/admins/show-order.blade.php ENDPATH**/ ?>