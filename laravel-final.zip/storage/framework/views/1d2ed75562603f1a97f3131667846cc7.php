
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4 d-inline">Foods</h5>
                        <a href="<?php echo e(route('admin.foods.create')); ?>"
                            class="btn btn-primary mb-4 text-center float-right">Create Foods</a>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">name</th>
                                    <th scope="col">image</th>
                                    <th scope="col">category</th>
                                    <th scope="col">description</th>
                                    <th scope="col">price</th>
                                    <th scope="col">delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo csrf_field(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($index + 1); ?></th>
                                        <td><?php echo e($food->name); ?></td>
                                        <td><img src="<?php echo e(asset('img/' . $food->image . '')); ?>" alt="<?php echo e($food->name); ?>"
                                                width="50">

                                        </td>
                                        <td><?php echo e($food->category); ?></td>
                                        <td><?php echo e($food->description); ?></td>
                                        <td>$<?php echo e($food->price); ?></td>
                                        <td>
                                            <button class="btn btn-warning"><a
                                                    href="<?php echo e(route('admin.foods.edit', $food->id)); ?>"
                                                    class="text-white">Edit</a></button>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.foods.delete', $food->id)); ?>" method="POST"
                                                class="d-inline">
                                                <?php echo csrf_field(); ?>

                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Are you sure?')">delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>



    </div>
    <script type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\restorant\resources\views/admins/show-foods.blade.php ENDPATH**/ ?>